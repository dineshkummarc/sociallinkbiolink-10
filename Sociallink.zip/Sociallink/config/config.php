<?php

return [
    'name' => 'Sociallink',
];
