<?php

namespace Modules\Sociallink\Database\Seeders;

use Illuminate\Database\Seeder;

class SociallinkDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
